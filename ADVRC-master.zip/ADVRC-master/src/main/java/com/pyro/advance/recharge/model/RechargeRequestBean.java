package com.pyro.advance.recharge.model;


public class RechargeRequestBean {
    private String inputType;
    private String srcMsisdn;
    private String mPin;
    private String destMsisdn;
    private String user;
    private String recordId;
    private String password;

    /**
     * @return the inputType
     */
    public String getInputType() {
        return inputType;
    }

    /**
     * @param inputType the inputType to set
     */
    public void setInputType(String inputType) {
        this.inputType = inputType;
    }

    /**
     * @return the srcMsisdn
     */
    public String getSrcMsisdn() {
        return srcMsisdn;
    }

    /**
     * @param srcMsisdn the srcMsisdn to set
     */
    public void setSrcMsisdn(String srcMsisdn) {
        this.srcMsisdn = srcMsisdn;
    }

    /**
     * @return the mPin
     */
    public String getmPin() {
        return mPin;
    }

    /**
     * @param mPin the mPin to set
     */
    public void setmPin(String mPin) {
        this.mPin = mPin;
    }

    /**
     * @return the destMsisdn
     */
    public String getDestMsisdn() {
        return destMsisdn;
    }

    /**
     * @param destMsisdn the destMsisdn to set
     */
    public void setDestMsisdn(String destMsisdn) {
        this.destMsisdn = destMsisdn;
    }

    /**
     * @return the user
     */
    public String getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     * @return the recordId
     */
    public String getRecordId() {
        return recordId;
    }

    /**
     * @param recordId the recordId to set
     */
    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }

    /**
     * @return the ip
     */


    /**
     * @param ip the ip to set
     */


    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }
    
    
    
}
